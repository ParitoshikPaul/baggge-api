<?php

namespace Drupal\social_auth\Plugin\Network;

use Drupal\social_api\Plugin\NetworkBase;

/**
 * Defines a Network Plugin for Social Widgets.
 */
abstract class SocialAuthNetwork extends NetworkBase implements SocialAuthNetworkInterface {}
