<?php

namespace Drupal\social_auth\Plugin\Network;

use Drupal\social_api\Plugin\NetworkInterface;

/**
 * Defines an interface for Social Auth Network.
 */
interface SocialAuthNetworkInterface extends NetworkInterface {}
